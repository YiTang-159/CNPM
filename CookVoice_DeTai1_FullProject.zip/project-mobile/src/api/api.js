// src/api/api.js
//
// Giống bản web: mặc định chạy chế độ MOCK (useMock: true trong app.json)
// để demo được luồng đầy đủ mà không cần Backend thật. Khi có API thật,
// đổi "useMock" thành false và điền đúng "apiBaseUrl" trong app.json.

import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";

const USE_MOCK = Constants.expoConfig?.extra?.useMock !== false;

const client = axios.create({
  baseURL: Constants.expoConfig?.extra?.apiBaseUrl,
});

client.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem("accessToken");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401) {
      await AsyncStorage.removeItem("accessToken");
    }
    return Promise.reject(err);
  }
);

// ---------------------------------------------------------------------
// MOCK ENGINE
// ---------------------------------------------------------------------
const STAGE_SEQUENCE = ["pending", "extracting", "translating", "dubbing", "done"];
const jobs = new Map();

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeJobId() {
  return "job_" + Math.random().toString(36).slice(2, 10);
}

async function mockUploadMedia(formData) {
  await delay(600);
  // React Native FormData không có .get() đầy đủ như web, nên ta lưu kèm
  // theo _parts nội bộ (RN) — đơn giản hoá bằng cách nhận object thường:
  const fileEntry = formData._parts?.find((p) => p[0] === "file")?.[1];
  const sourceLang = formData._parts?.find((p) => p[0] === "sourceLang")?.[1];
  const targetLang = formData._parts?.find((p) => p[0] === "targetLang")?.[1];

  const jobId = makeJobId();
  jobs.set(jobId, {
    uri: fileEntry?.uri,
    fileName: fileEntry?.name || "video.mp4",
    sourceLang,
    targetLang,
    startedAt: Date.now(),
  });

  return { data: { success: true, jobId } };
}

async function mockCheckStatus(jobId) {
  await delay(400);
  const job = jobs.get(jobId);
  if (!job) {
    const err = new Error("Not found");
    err.response = { data: { success: false, errorCode: "JOB_NOT_FOUND", message: "Không tìm thấy tiến trình xử lý." } };
    throw err;
  }
  const elapsed = Date.now() - job.startedAt;
  const STAGE_DURATION = 2200;
  const stageIndex = Math.min(Math.floor(elapsed / STAGE_DURATION), STAGE_SEQUENCE.length - 1);
  const status = STAGE_SEQUENCE[stageIndex];
  const progress = Math.min(100, Math.round((elapsed / (STAGE_DURATION * (STAGE_SEQUENCE.length - 1))) * 100));
  return { data: { success: true, status, progress } };
}

async function mockGetResult(jobId) {
  await delay(400);
  const job = jobs.get(jobId);
  if (!job) {
    const err = new Error("Not found");
    err.response = { data: { success: false, errorCode: "JOB_NOT_FOUND", message: "Không tìm thấy kết quả." } };
    throw err;
  }
  return {
    data: {
      success: true,
      videoUrl: job.uri, // demo: phát lại video gốc do chưa có BE lồng tiếng thật
      audioUrl: job.uri,
      subtitleUrl: null,
      sourceLang: job.sourceLang,
      targetLang: job.targetLang,
      fileName: job.fileName,
    },
  };
}

// ---------------------------------------------------------------------
// EXPORTS
// ---------------------------------------------------------------------
export const register = (data) =>
  USE_MOCK ? Promise.resolve({ data: { success: true } }) : client.post("/auth/register", data);

export const login = (data) =>
  USE_MOCK ? Promise.resolve({ data: { success: true, accessToken: "mock-token" } }) : client.post("/auth/login", data);

export const uploadMedia = (formData) =>
  USE_MOCK
    ? mockUploadMedia(formData)
    : client.post("/media/upload", formData, { headers: { "Content-Type": "multipart/form-data" } });

export const checkStatus = (jobId) => (USE_MOCK ? mockCheckStatus(jobId) : client.get(`/media/status/${jobId}`));

export const getResult = (jobId) => (USE_MOCK ? mockGetResult(jobId) : client.get(`/media/result/${jobId}`));
