import { View, Text, StyleSheet } from "react-native";
import { Picker } from "@react-native-picker/picker";

const LANGUAGES = [
  { code: "vi", label: "Tiếng Việt" },
  { code: "en", label: "English" },
  { code: "ja", label: "日本語" },
  { code: "ko", label: "한국어" },
  { code: "fr", label: "Français" },
];

export default function LanguagePicker({ source, target, onChangeSource, onChangeTarget }) {
  return (
    <View style={styles.row}>
      <View style={styles.col}>
        <Text style={styles.label}>Ngôn ngữ nguồn</Text>
        <Picker selectedValue={source} onValueChange={onChangeSource}>
          {LANGUAGES.map((l) => (
            <Picker.Item key={l.code} label={l.label} value={l.code} />
          ))}
        </Picker>
      </View>
      <View style={styles.col}>
        <Text style={styles.label}>Ngôn ngữ đích</Text>
        <Picker selectedValue={target} onValueChange={onChangeTarget}>
          {LANGUAGES.map((l) => (
            <Picker.Item key={l.code} label={l.label} value={l.code} />
          ))}
        </Picker>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { marginVertical: 12 },
  col: { marginBottom: 12 },
  label: { fontSize: 14, fontWeight: "600", marginBottom: 4, color: "#33261F" },
});
