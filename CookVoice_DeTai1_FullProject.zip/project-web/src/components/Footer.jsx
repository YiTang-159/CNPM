export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 CookVoice — Thuyết minh công thức nấu ăn đa ngôn ngữ · Đồ án tốt nghiệp</p>
    </footer>
  );
}
