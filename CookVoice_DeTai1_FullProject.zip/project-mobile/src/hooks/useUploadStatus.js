import { useEffect, useRef, useState } from "react";
import { checkStatus } from "../api/api";

const POLL_INTERVAL_MS = 1200;

export function useUploadStatus(jobId) {
  const [status, setStatus] = useState("pending");
  const [percent, setPercent] = useState(0);
  const [error, setError] = useState("");
  const timerRef = useRef(null);

  useEffect(() => {
    if (!jobId) return;

    async function poll() {
      try {
        const res = await checkStatus(jobId);
        const { status: s, progress } = res.data;
        setStatus(s);
        setPercent(progress ?? 0);

        if (s === "failed") {
          setError(res.data.message || "Xử lý thất bại.");
          clearInterval(timerRef.current);
        }
        if (s === "done") {
          clearInterval(timerRef.current);
        }
      } catch (err) {
        if (!err.response) return;
        setError(err.response?.data?.message || "Mất kết nối tới máy chủ.");
        clearInterval(timerRef.current);
      }
    }

    poll();
    timerRef.current = setInterval(poll, POLL_INTERVAL_MS);
    return () => clearInterval(timerRef.current);
  }, [jobId]);

  return { status, percent, error };
}
