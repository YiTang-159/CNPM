import { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ProgressBar from "../components/ProgressBar";
import { useUploadStatus } from "../hooks/useUploadStatus";

const STAGES = [
  { key: "pending", label: "Đang chờ xử lý" },
  { key: "extracting", label: "Tách audio" },
  { key: "translating", label: "Dịch công thức" },
  { key: "dubbing", label: "Tạo giọng thuyết minh" },
  { key: "done", label: "Hoàn tất" },
];

export default function Processing() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const { status, percent, error } = useUploadStatus(jobId);

  useEffect(() => {
    if (status === "done") {
      const t = setTimeout(() => navigate(`/result/${jobId}`), 400);
      return () => clearTimeout(t);
    }
  }, [status, jobId, navigate]);

  if (error) {
    return (
      <section className="processing-page">
        <h2>Xử lý thất bại</h2>
        <p className="error-text">{error}</p>
        <button className="btn-secondary" onClick={() => navigate("/upload")}>
          Thử lại
        </button>
      </section>
    );
  }

  const currentIndex = STAGES.findIndex((s) => s.key === status);

  return (
    <section className="processing-page">
      <h2>🍳 Đang chế biến bản thuyết minh của bạn...</h2>
      <ProgressBar percent={percent} />
      <div className="stage-list">
        {STAGES.map((s, i) => (
          <span key={s.key} className={"stage-item" + (i <= currentIndex ? " active" : "")}>
            {s.label}
          </span>
        ))}
      </div>
    </section>
  );
}
