const LANGUAGES = [
  { code: "vi", label: "Tiếng Việt" },
  { code: "en", label: "English" },
  { code: "ja", label: "日本語" },
  { code: "ko", label: "한국어" },
  { code: "fr", label: "Français" },
];

export default function LanguageSelect({ source, target, onChangeSource, onChangeTarget }) {
  return (
    <div className="lang-select">
      <div>
        <label>Ngôn ngữ nguồn (video gốc)</label>
        <select value={source} onChange={(e) => onChangeSource(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>
      <div>
        <label>Ngôn ngữ đích (muốn dịch sang)</label>
        <select value={target} onChange={(e) => onChangeTarget(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>
    </div>
  );
}
