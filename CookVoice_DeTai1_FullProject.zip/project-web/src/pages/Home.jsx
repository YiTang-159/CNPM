import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();
  return (
    <section className="home">
      <span className="badge">🍜 Dành cho nhà sáng tạo nội dung ẩm thực</span>
      <h1>Đưa công thức nấu ăn của bạn ra thế giới</h1>
      <p className="desc">
        Tải video nấu ăn hoặc hướng dẫn công thức lên, chọn ngôn ngữ nguồn và
        đích — CookVoice tự động dịch và tạo giọng thuyết minh mới, giúp khán
        giả ở bất kỳ đâu cũng hiểu được món ăn của bạn.
      </p>
      <button className="btn-primary" onClick={() => navigate("/upload")}>
        Bắt đầu dịch video
      </button>

      <div className="features">
        <div className="feature-card">
          <div className="icon">🎙️</div>
          <h3>Thuyết minh tự động</h3>
          <p>Tạo giọng đọc mới cho công thức, không chỉ dịch phụ đề.</p>
        </div>
        <div className="feature-card">
          <div className="icon">🌍</div>
          <h3>Đa ngôn ngữ</h3>
          <p>Hỗ trợ Việt, Anh, Nhật, Hàn, Pháp và nhiều ngôn ngữ khác.</p>
        </div>
        <div className="feature-card">
          <div className="icon">⏱️</div>
          <h3>Nhanh chóng</h3>
          <p>Theo dõi tiến trình xử lý theo thời gian thực, tải kết quả ngay khi xong.</p>
        </div>
      </div>
    </section>
  );
}
