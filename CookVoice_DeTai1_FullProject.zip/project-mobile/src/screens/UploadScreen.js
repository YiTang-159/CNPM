import { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Alert, ScrollView } from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as Linking from "expo-linking";
import LanguagePicker from "../components/LanguagePicker";
import { uploadMedia } from "../api/api";

const MAX_SIZE_MB = 200;

function showPermissionAlert(permissionName) {
  Alert.alert(
    "Cần quyền truy cập",
    `Ứng dụng cần quyền ${permissionName} để tiếp tục. Vui lòng bật trong Cài đặt.`,
    [
      { text: "Huỷ", style: "cancel" },
      { text: "Mở Cài đặt", onPress: () => Linking.openSettings() },
    ]
  );
}

export default function UploadScreen({ navigation }) {
  const [video, setVideo] = useState(null);
  const [source, setSource] = useState("vi");
  const [target, setTarget] = useState("en");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  async function pickFromLibrary() {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      showPermissionAlert("Thư viện ảnh/video");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      quality: 1,
    });
    if (!result.canceled) handlePicked(result.assets[0]);
  }

  async function recordNewVideo() {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      showPermissionAlert("Camera");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Videos });
    if (!result.canceled) handlePicked(result.assets[0]);
  }

  function handlePicked(asset) {
    const sizeMB = (asset.fileSize || 0) / (1024 * 1024);
    if (sizeMB > MAX_SIZE_MB) {
      setErrorMsg(`File vượt quá ${MAX_SIZE_MB}MB.`);
      return;
    }
    setErrorMsg("");
    setVideo(asset);
  }

  async function handleSubmit() {
    if (!video) {
      setErrorMsg("Vui lòng chọn hoặc quay video công thức trước.");
      return;
    }
    if (source === target) {
      setErrorMsg("Ngôn ngữ nguồn và đích không được trùng nhau.");
      return;
    }
    setLoading(true);
    setErrorMsg("");
    try {
      const formData = new FormData();
      formData.append("file", {
        uri: video.uri,
        name: video.fileName || "video.mp4",
        type: "video/mp4",
      });
      formData.append("sourceLang", source);
      formData.append("targetLang", target);

      const res = await uploadMedia(formData);
      const jobId = res.data.jobId;
      navigation.replace("Processing", { jobId });
    } catch (err) {
      setErrorMsg(err.response?.data?.message || "Upload thất bại, thử lại sau.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Tải video công thức lên</Text>
      <Text style={styles.hint}>Gợi ý: video nấu ăn, hướng dẫn công thức, review món ăn.</Text>

      <TouchableOpacity style={styles.pickBtn} onPress={pickFromLibrary}>
        <Text style={styles.pickBtnText}>📁 Chọn video từ thư viện</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.pickBtn} onPress={recordNewVideo}>
        <Text style={styles.pickBtnText}>🎥 Quay video mới</Text>
      </TouchableOpacity>

      {video && <Text style={styles.fileName}>Đã chọn: {video.fileName || "video.mp4"}</Text>}

      <LanguagePicker source={source} target={target} onChangeSource={setSource} onChangeTarget={setTarget} />

      {errorMsg ? <Text style={styles.error}>{errorMsg}</Text> : null}

      <TouchableOpacity style={styles.submitBtn} disabled={loading} onPress={handleSubmit}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.submitText}>Bắt đầu xử lý</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  heading: { fontSize: 20, fontWeight: "bold", marginBottom: 4, color: "#33261F" },
  hint: { fontSize: 13, color: "#7A6A5D", marginBottom: 16 },
  pickBtn: { backgroundColor: "#FBF1E7", padding: 14, borderRadius: 10, marginBottom: 10, alignItems: "center" },
  pickBtnText: { fontWeight: "600", color: "#33261F" },
  fileName: { marginVertical: 8, color: "#7A6A5D" },
  error: { color: "#D33333", marginVertical: 8 },
  submitBtn: { backgroundColor: "#D9622B", padding: 14, borderRadius: 10, alignItems: "center", marginTop: 16 },
  submitText: { color: "#fff", fontWeight: "600", fontSize: 16 },
});
