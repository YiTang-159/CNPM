import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="header">
      <Link to="/" className="logo">
        <span className="logo-mark">🍲</span> CookVoice
      </Link>
      <nav className="lang-switch">
        <button type="button">VI</button>
        <button type="button">EN</button>
      </nav>
    </header>
  );
}
