# CookVoice — Web (project-web)

Web app dịch video nấu ăn / công thức sang nhiều ngôn ngữ, thuộc Đề tài 1:
FE Dev — Thuyết minh tự động đa ngôn ngữ.

## Công nghệ
React.js + Vite, Axios, React Router.

## Cài đặt & chạy local
```bash
npm install
cp .env.example .env
npm run dev
```
Mặc định chạy ở chế độ **mock** (VITE_USE_MOCK=true trong .env.example) —
không cần Backend thật vẫn demo được đầy đủ luồng Upload → Processing → Result.

## Nối API thật
Khi nhóm Backend đã sẵn sàng:
1. Đặt `VITE_USE_MOCK=false` trong `.env`
2. Điền đúng `VITE_API_BASE_URL`
3. Không cần sửa code — `src/api/api.js` tự chuyển sang gọi API thật.

## Build production
```bash
npm run build
```

## Cấu trúc thư mục
```
src/
├── pages/        Home, Upload, Processing, Result
├── components/   Header, Footer, FileDropzone, LanguageSelect, ProgressBar, VideoPlayer
├── api/api.js    Lớp giao tiếp API (có sẵn mock engine)
├── hooks/        useUploadStatus.js (polling trạng thái xử lý)
└── utils/        errorMessages.js (ánh xạ errorCode -> thông báo)
```

## Deploy
Tự động deploy lên Vercel khi push vào nhánh `main` (xem `.github/workflows/deploy.yml`,
hoặc đơn giản hơn: import repo trực tiếp trên vercel.com để dùng auto-deploy có sẵn).

## Nhóm phát triển
- SV1: Web Frontend
- SV2: Mobile Frontend
- SV3: Shared Logic & CI/CD
