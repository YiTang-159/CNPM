# API_CONTRACT.md — CookVoice (Đề tài 1: Thuyết minh tự động đa ngôn ngữ)

## 1. Base URL
- Development: http://localhost:3000/api
- Production: https://api.yourapp.onrender.com/api

## 2. Auth
- Header: `Authorization: Bearer <accessToken>`
- Token hết hạn sau 24h -> BE trả 401 khi hết hạn

## 3. Endpoints

### POST /auth/register
Request: `{ "email": string, "password": string, "name": string }`
Response 200: `{ "success": true, "userId": string }`

### POST /auth/login
Request: `{ "email": string, "password": string }`
Response 200: `{ "success": true, "accessToken": string }`

### POST /media/upload (multipart/form-data)
Fields: `file` (binary — video nấu ăn), `sourceLang` (string), `targetLang` (string)
Response 200: `{ "success": true, "jobId": string }`

### GET /media/status/{jobId}
Response 200:
```json
{
  "success": true,
  "status": "pending" | "extracting" | "translating" | "dubbing" | "done" | "failed",
  "progress": 0,
  "message": "chỉ có khi status = failed"
}
```

### GET /media/result/{jobId}
Response 200:
```json
{
  "success": true,
  "videoUrl": "string",
  "audioUrl": "string",
  "subtitleUrl": "string"
}
```

## 4. Cấu trúc lỗi chung
`{ "success": false, "errorCode": string, "message": string }`

errorCode gồm: FILE_TOO_LARGE, UNSUPPORTED_FORMAT, UNSUPPORTED_LANGUAGE,
JOB_NOT_FOUND, UNAUTHORIZED, SERVER_ERROR

## 5. Lưu ý riêng cho chủ đề "video nấu ăn"
- Giới hạn thời lượng video khuyến nghị: dưới 15 phút/video (video nấu ăn
  thường không quá dài, giúp giảm thời gian xử lý và chi phí TTS).
- Ngôn ngữ hỗ trợ tối thiểu: vi, en, ja, ko, fr (đủ cho nhóm khán giả ẩm
  thực phổ biến trên YouTube/TikTok).
