// src/utils/errorMessages.js
export const ERROR_MESSAGES = {
  FILE_TOO_LARGE: "File vượt quá dung lượng cho phép (200MB).",
  UNSUPPORTED_FORMAT: "Định dạng file không được hỗ trợ.",
  UNSUPPORTED_LANGUAGE: "Ngôn ngữ được chọn hiện chưa hỗ trợ.",
  JOB_NOT_FOUND: "Không tìm thấy tiến trình xử lý.",
  UNAUTHORIZED: "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại.",
  SERVER_ERROR: "Có lỗi xảy ra ở máy chủ, vui lòng thử lại sau.",
};

export function getErrorMessage(err) {
  const code = err.response?.data?.errorCode;
  return ERROR_MESSAGES[code] || err.response?.data?.message || "Đã có lỗi xảy ra.";
}
