# CookVoice — Đề tài 1: FE Dev (Thuyết minh tự động đa ngôn ngữ)

Chủ đề: **dịch video nấu ăn / công thức sang nhiều ngôn ngữ.**

## Cấu trúc repo trong gói này
```
project-web/       Web (React + Vite) — SV1 phụ trách, đã có mock engine, chạy được ngay
project-mobile/    Mobile (React Native + Expo) — SV2 phụ trách, đã có mock engine
shared/            Tài liệu dùng chung — SV3 phụ trách
  ├── API_CONTRACT.md
  └── DESIGN_SYSTEM.md
```

## Chạy thử nhanh (web)
```bash
cd project-web
npm install
npm run dev
```
Mở http://localhost:5173 — chạy được ngay với dữ liệu mock, không cần Backend thật.
Luồng demo: Home → Upload (chọn video bất kỳ + chọn ngôn ngữ) → Processing
(progress bar tự chạy ~9 giây) → Result (phát lại video, có nút tải).

## Chạy thử nhanh (mobile)
```bash
cd project-mobile
npm install
npx expo start
```
Quét mã QR bằng Expo Go trên điện thoại thật (cùng mạng WiFi với máy tính).

## Vì sao dùng "mock" thay vì API thật?
Đây là FE-only project (Backend thuộc đề tài 2, 3 do nhóm khác làm). Để nhóm
có thể tự chạy, demo, và báo cáo tiến độ độc lập — cả 2 project đều có sẵn
một "mock engine" mô phỏng hành vi Backend thật (tạo jobId, tiến trình xử lý
qua các bước pending → extracting → translating → dubbing → done, trả về
kết quả). Khi nhóm Backend đã sẵn sàng, chỉ cần đổi 1 dòng cấu hình
(`VITE_USE_MOCK=false` ở web, `useMock: false` ở mobile) để chuyển sang gọi
API thật — không cần sửa lại UI hay logic các trang.

## Việc còn cần làm để hoàn thiện (theo phân công gốc)
- SV1: tinh chỉnh responsive, thêm xử lý edge case (mất mạng thật, không
  chỉ mất mạng giả lập), setup deploy Vercel thật
- SV2: test trên thiết bị Android/iOS thật, build APK qua EAS thật
- SV3: họp chốt API_CONTRACT.md thật với nhóm Backend, setup GitHub Actions
  thật trên repo (workflow mẫu đã có sẵn trong `.github/workflows/` của
  mỗi project), viết tài liệu kỹ thuật báo cáo cuối kỳ
