import { Video, ResizeMode } from "expo-av";
import { StyleSheet } from "react-native";

export default function VideoPlayer({ uri }) {
  return (
    <Video
      style={styles.video}
      source={{ uri }}
      useNativeControls
      resizeMode={ResizeMode.CONTAIN}
    />
  );
}

const styles = StyleSheet.create({
  video: { width: "100%", height: 220, borderRadius: 12, backgroundColor: "#000" },
});
