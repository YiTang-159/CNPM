import { useEffect, useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView } from "react-native";
import * as FileSystem from "expo-file-system";
import * as MediaLibrary from "expo-media-library";
import * as Sharing from "expo-sharing";
import VideoPlayer from "../components/VideoPlayer";
import { getResult } from "../api/api";

export default function ResultScreen({ route, navigation }) {
  const { jobId } = route.params;
  const [data, setData] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    getResult(jobId)
      .then((res) => setData(res.data))
      .catch((err) => setErrorMsg(err.response?.data?.message || "Không tải được kết quả."));
  }, [jobId]);

  async function handleSave() {
    const perm = await MediaLibrary.requestPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("Cần quyền truy cập", "Vui lòng cấp quyền lưu trữ để tải video về máy.");
      return;
    }
    await MediaLibrary.saveToLibraryAsync(data.videoUrl);
    Alert.alert("Thành công", "Đã lưu video vào thư viện.");
  }

  async function handleShare() {
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(data.videoUrl);
    }
  }

  if (errorMsg) return <Text style={styles.error}>{errorMsg}</Text>;
  if (!data) return <Text style={styles.loading}>Đang tải kết quả...</Text>;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>🎉 Công thức của bạn đã sẵn sàng!</Text>
      <View style={styles.mockBanner}>
        <Text style={styles.mockBannerText}>
          Đây là bản demo (mock) — video dưới đây phát lại video gốc do chưa nối Backend thật.
        </Text>
      </View>
      <VideoPlayer uri={data.videoUrl} />
      <TouchableOpacity style={styles.btn} onPress={handleSave}>
        <Text style={styles.btnText}>Lưu về máy</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={handleShare}>
        <Text style={styles.btnText}>Chia sẻ</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btnOutline} onPress={() => navigation.navigate("Upload")}>
        <Text style={styles.btnOutlineText}>Dịch công thức khác</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: "#FFFDF9" },
  heading: { fontSize: 20, fontWeight: "bold", marginBottom: 12, color: "#33261F" },
  mockBanner: { backgroundColor: "#FFF6DA", borderColor: "#E0A82E", borderWidth: 1, borderRadius: 10, padding: 12, marginBottom: 16 },
  mockBannerText: { fontSize: 12, color: "#6B4E12" },
  btn: { backgroundColor: "#D9622B", padding: 14, borderRadius: 10, alignItems: "center", marginTop: 12 },
  btnText: { color: "#fff", fontWeight: "600" },
  btnOutline: { borderWidth: 1, borderColor: "#D9622B", padding: 14, borderRadius: 10, alignItems: "center", marginTop: 12 },
  btnOutlineText: { color: "#B84E1F", fontWeight: "600" },
  error: { color: "#D33333", padding: 20 },
  loading: { padding: 20 },
});
