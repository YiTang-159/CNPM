export default function ProgressBar({ percent }) {
  return (
    <div className="progress-track">
      <div className="progress-fill" style={{ width: `${percent}%` }} />
      <span>{percent}%</span>
    </div>
  );
}
