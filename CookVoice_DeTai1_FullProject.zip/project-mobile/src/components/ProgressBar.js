import { View, Text, StyleSheet } from "react-native";

export default function ProgressBar({ percent }) {
  return (
    <View style={styles.track}>
      <View style={[styles.fill, { width: `${percent}%` }]} />
      <Text style={styles.label}>{percent}%</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  track: { height: 24, backgroundColor: "#FBF1E7", borderRadius: 12, overflow: "hidden", justifyContent: "center" },
  fill: { position: "absolute", left: 0, top: 0, bottom: 0, backgroundColor: "#D9622B" },
  label: { textAlign: "center", fontSize: 12, fontWeight: "700", color: "#33261F" },
});
