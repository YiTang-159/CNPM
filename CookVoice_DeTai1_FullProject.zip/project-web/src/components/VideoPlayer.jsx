export default function VideoPlayer({ src }) {
  return <video className="video-player" src={src} controls />;
}
