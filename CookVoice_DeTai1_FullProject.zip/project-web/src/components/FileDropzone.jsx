import { useRef, useState } from "react";

const ALLOWED_TYPES = ["video/mp4", "audio/mpeg", "audio/wav"];
const MAX_SIZE_MB = 200;

export default function FileDropzone({ onFileSelected }) {
  const inputRef = useRef(null);
  const [error, setError] = useState("");
  const [fileName, setFileName] = useState("");

  function validateAndSet(file) {
    if (!file) return;
    if (!ALLOWED_TYPES.includes(file.type)) {
      setError("Định dạng không hỗ trợ. Chỉ nhận video mp4 hoặc audio mp3/wav.");
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File vượt quá ${MAX_SIZE_MB}MB.`);
      return;
    }
    setError("");
    setFileName(file.name);
    onFileSelected(file);
  }

  function handleDrop(e) {
    e.preventDefault();
    validateAndSet(e.dataTransfer.files[0]);
  }

  return (
    <div>
      <div
        className="dropzone"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={() => inputRef.current.click()}
      >
        <input
          ref={inputRef}
          type="file"
          hidden
          accept="video/mp4,audio/mpeg,audio/wav"
          onChange={(e) => validateAndSet(e.target.files[0])}
        />
        {fileName ? (
          <>
            <p className="dz-title">🎬 Đã chọn: {fileName}</p>
            <p>Bấm để chọn video công thức khác</p>
          </>
        ) : (
          <>
            <p className="dz-title">Kéo-thả video công thức nấu ăn vào đây</p>
            <p>hoặc bấm để chọn file (mp4, mp3, wav — tối đa {MAX_SIZE_MB}MB)</p>
          </>
        )}
      </div>
      {error && <p className="error-text">{error}</p>}
    </div>
  );
}
