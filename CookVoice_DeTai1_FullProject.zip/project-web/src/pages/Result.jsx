import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import VideoPlayer from "../components/VideoPlayer";
import { getResult } from "../api/api";
import { getErrorMessage } from "../utils/errorMessages";

const LANGUAGE_LABEL = {
  vi: "Tiếng Việt", en: "English", ja: "日本語", ko: "한국어", fr: "Français",
};

export default function Result() {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    getResult(jobId)
      .then((res) => setData(res.data))
      .catch((err) => setErrorMsg(getErrorMessage(err)));
  }, [jobId]);

  if (errorMsg) return <p className="error-text">{errorMsg}</p>;
  if (!data) return <p>Đang tải kết quả...</p>;

  return (
    <section className="result-page">
      <h2>🎉 Công thức của bạn đã sẵn sàng!</h2>

      <div className="mock-banner">
        Đây là bản demo giao diện (mock) — vì chưa nối Backend thật nên video
        dưới đây phát lại chính video gốc bạn đã tải lên, thay cho bản đã
        được lồng tiếng.
      </div>

      <div>
        <span className="recipe-tag">Nguồn: {LANGUAGE_LABEL[data.sourceLang] || data.sourceLang}</span>
        <span className="recipe-tag">Đích: {LANGUAGE_LABEL[data.targetLang] || data.targetLang}</span>
      </div>

      <VideoPlayer src={data.videoUrl} />

      <div className="result-actions">
        <a href={data.videoUrl} download={data.fileName || "video.mp4"}>⬇️ Tải video</a>
        <a href={data.audioUrl} download="audio.mp3">⬇️ Tải audio</a>
        <a href={data.subtitleUrl} download="subtitle.vtt">⬇️ Tải phụ đề</a>
      </div>

      <button className="btn-secondary" onClick={() => navigate("/upload")}>
        Dịch công thức khác
      </button>
    </section>
  );
}
