# Design System tối thiểu — CookVoice

## Bảng màu (tông "bếp ấm áp", đã áp dụng vào cả web & mobile)
| Tên            | Mã màu   | Dùng cho |
|----------------|----------|----------|
| Primary        | #D9622B  | Nút chính, tiêu đề nhấn mạnh |
| Primary Dark   | #B84E1F  | Hover, logo |
| Success        | #2F9E5B  | Trạng thái thành công |
| Error          | #D33333  | Thông báo lỗi |
| Warning        | #E0A82E  | Banner cảnh báo/lưu ý |
| Text chính     | #33261F  | Chữ nội dung |
| Text phụ       | #7A6A5D  | Chữ mô tả, hint |
| Nền            | #FFFDF9  | Nền trang |
| Nền phụ        | #FBF1E7  | Card, dropzone, badge |

## Spacing & Typography
- Spacing scale: 4, 8, 12, 16, 20, 24, 32 (px)
- Font: hệ thống mặc định (web: -apple-system/Segoe UI; mobile: San Francisco/Roboto)
- Cỡ chữ: Heading 24-32px, Subheading 18-22px, Body 15px, Caption 13px
- Bo góc nút/card: 10-12px

## Quy ước đặt tên component
- Component: PascalCase — `FileDropzone`, `LanguageSelect`, `ProgressBar`, `VideoPlayer`
- File trùng tên component
- Props: camelCase — `onFileSelected`, `sourceLang`, `targetLang`
- Class CSS (web): kebab-case — `.btn-primary`, `.lang-select`, `.error-text`

## Nội dung/copy theo chủ đề nấu ăn
- Xưng hô: gần gũi, thân thiện ("công thức của bạn", "món ăn của bạn")
- Icon minh hoạ: 🍲 🍳 🎙️ 🌍 ⏱️ — dùng nhất quán giữa web và mobile
- Banner "mock/demo" luôn hiển thị ở trang Result khi chưa nối Backend thật,
  để tránh gây hiểu lầm với giảng viên/người xem demo.
