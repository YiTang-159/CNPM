import { useState } from "react";
import { useNavigate } from "react-router-dom";
import FileDropzone from "../components/FileDropzone";
import LanguageSelect from "../components/LanguageSelect";
import { uploadMedia } from "../api/api";
import { getErrorMessage } from "../utils/errorMessages";

export default function Upload() {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [source, setSource] = useState("vi");
  const [target, setTarget] = useState("en");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit() {
    if (!file) {
      setErrorMsg("Vui lòng chọn video công thức trước khi tiếp tục.");
      return;
    }
    if (source === target) {
      setErrorMsg("Ngôn ngữ nguồn và ngôn ngữ đích không được trùng nhau.");
      return;
    }
    setLoading(true);
    setErrorMsg("");
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("sourceLang", source);
      formData.append("targetLang", target);

      const res = await uploadMedia(formData);
      const jobId = res.data.jobId;
      navigate(`/processing/${jobId}`);
    } catch (err) {
      setErrorMsg(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="upload-page">
      <h2>Tải video công thức lên</h2>
      <p className="hint-text" style={{ marginBottom: 16 }}>
        Gợi ý: video hướng dẫn nấu ăn, review món ăn, hoặc video công thức dạng nói chuyện trực tiếp.
      </p>
      <FileDropzone onFileSelected={setFile} />
      <LanguageSelect
        source={source}
        target={target}
        onChangeSource={setSource}
        onChangeTarget={setTarget}
      />
      {errorMsg && <p className="error-text">{errorMsg}</p>}
      <button className="btn-primary" disabled={loading} onClick={handleSubmit}>
        {loading ? "Đang tải lên..." : "Bắt đầu xử lý"}
      </button>
    </section>
  );
}
