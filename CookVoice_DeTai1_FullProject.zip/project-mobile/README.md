# CookVoice — Mobile (project-mobile)

App di động (React Native / Expo) dịch video nấu ăn / công thức sang nhiều
ngôn ngữ, thuộc Đề tài 1: FE Dev — Thuyết minh tự động đa ngôn ngữ.

## Cài đặt & chạy local
```bash
npm install
npx expo start
```
Quét mã QR bằng app Expo Go trên điện thoại (Android/iOS cùng mạng WiFi).

Mặc định chạy chế độ **mock** (`extra.useMock: true` trong `app.json`) — demo
được đầy đủ luồng mà chưa cần Backend thật.

## Nối API thật
Sửa trong `app.json`:
```json
"extra": {
  "apiBaseUrl": "http://<ip-hoac-domain-be-that>/api",
  "useMock": false
}
```

## Build APK (EAS Build)
```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

## Cấu trúc thư mục
```
src/
├── screens/       HomeScreen, UploadScreen, ProcessingScreen, ResultScreen
├── components/    LanguagePicker, ProgressBar, VideoPlayer
├── navigation/     AppNavigator.js
├── api/api.js      Lớp giao tiếp API (có sẵn mock engine)
└── hooks/          useUploadStatus.js
```

## Nhóm phát triển
- SV1: Web Frontend
- SV2: Mobile Frontend
- SV3: Shared Logic & CI/CD
