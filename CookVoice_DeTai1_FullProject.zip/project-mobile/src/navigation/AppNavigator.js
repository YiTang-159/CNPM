import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import HomeScreen from "../screens/HomeScreen";
import UploadScreen from "../screens/UploadScreen";
import ProcessingScreen from "../screens/ProcessingScreen";
import ResultScreen from "../screens/ResultScreen";

const Stack = createNativeStackNavigator();

const theme = {
  colors: {
    primary: "#D9622B",
  },
};

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{ headerTintColor: "#33261F", headerStyle: { backgroundColor: "#FBF1E7" } }}
      >
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: "CookVoice" }} />
        <Stack.Screen name="Upload" component={UploadScreen} options={{ title: "Tải video lên" }} />
        <Stack.Screen name="Processing" component={ProcessingScreen} options={{ title: "Đang xử lý", headerBackVisible: false }} />
        <Stack.Screen name="Result" component={ResultScreen} options={{ title: "Kết quả" }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
