// src/api/api.js
//
// File này đóng vai trò lớp giao tiếp API dùng chung (theo đúng vai trò SV3
// cung cấp trong phân công của nhóm). Vì đồ án FE này làm độc lập, chưa có
// Backend thật (đề tài 2, 3), nên mặc định chạy ở chế độ MOCK: mọi request
// được giả lập ngay trong trình duyệt, không gọi ra mạng.
//
// Khi nhóm Backend đã có API thật, chỉ cần:
//   1. Đặt VITE_USE_MOCK=false trong file .env
//   2. Điền đúng VITE_API_BASE_URL
//   3. Không cần sửa gì ở các trang Upload/Processing/Result vì interface
//      (tên hàm, hình dạng dữ liệu trả về) giữ nguyên như khi dùng thật.

import axios from "axios";

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== "false";

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:3000/api",
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("accessToken");
    }
    return Promise.reject(err);
  }
);

// ---------------------------------------------------------------------
// MOCK ENGINE — giả lập một "Backend" tách audio / dịch / lồng tiếng
// ---------------------------------------------------------------------
const STAGE_SEQUENCE = ["pending", "extracting", "translating", "dubbing", "done"];
const jobs = new Map();

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeJobId() {
  return "job_" + Math.random().toString(36).slice(2, 10);
}

const LANGUAGE_LABEL = {
  vi: "Tiếng Việt", en: "English", ja: "日本語", ko: "한국어", fr: "Français",
};

async function mockUploadMedia(formData) {
  await delay(600);
  const file = formData.get("file");
  const sourceLang = formData.get("sourceLang");
  const targetLang = formData.get("targetLang");

  if (!file) {
    const err = new Error("Missing file");
    err.response = { data: { success: false, errorCode: "UNSUPPORTED_FORMAT", message: "Không có file được gửi lên." } };
    throw err;
  }

  const jobId = makeJobId();
  jobs.set(jobId, {
    objectUrl: URL.createObjectURL(file),
    fileName: file.name,
    sourceLang,
    targetLang,
    startedAt: Date.now(),
  });

  return { data: { success: true, jobId } };
}

async function mockCheckStatus(jobId) {
  await delay(400);
  const job = jobs.get(jobId);
  if (!job) {
    const err = new Error("Not found");
    err.response = { data: { success: false, errorCode: "JOB_NOT_FOUND", message: "Không tìm thấy tiến trình xử lý." } };
    throw err;
  }

  // Giả lập tiến trình: mỗi giai đoạn mất ~2.2 giây, tổng cộng ~9 giây cho cả job
  const elapsed = Date.now() - job.startedAt;
  const STAGE_DURATION = 2200;
  const stageIndex = Math.min(
    Math.floor(elapsed / STAGE_DURATION),
    STAGE_SEQUENCE.length - 1
  );
  const status = STAGE_SEQUENCE[stageIndex];
  const progress = Math.min(100, Math.round((elapsed / (STAGE_DURATION * (STAGE_SEQUENCE.length - 1))) * 100));

  return { data: { success: true, status, progress } };
}

async function mockGetResult(jobId) {
  await delay(400);
  const job = jobs.get(jobId);
  if (!job) {
    const err = new Error("Not found");
    err.response = { data: { success: false, errorCode: "JOB_NOT_FOUND", message: "Không tìm thấy kết quả." } };
    throw err;
  }
  const subtitleContent =
    "WEBVTT\n\n00:00:00.000 --> 00:00:04.000\n" +
    `(Bản thuyết minh minh hoạ — ${LANGUAGE_LABEL[job.targetLang] || job.targetLang})\n\n` +
    "00:00:04.000 --> 00:00:08.000\nĐây là bản demo, chưa nối Backend thật.\n";
  const subtitleUrl = URL.createObjectURL(new Blob([subtitleContent], { type: "text/vtt" }));

  return {
    data: {
      success: true,
      videoUrl: job.objectUrl, // demo: phát lại chính video gốc do chưa có BE lồng tiếng thật
      audioUrl: job.objectUrl,
      subtitleUrl,
      sourceLang: job.sourceLang,
      targetLang: job.targetLang,
      fileName: job.fileName,
    },
  };
}

// ---------------------------------------------------------------------
// EXPORTS — interface giữ nguyên dù dùng mock hay API thật
// ---------------------------------------------------------------------
export const register = (data) =>
  USE_MOCK ? Promise.resolve({ data: { success: true } }) : client.post("/auth/register", data);

export const login = (data) =>
  USE_MOCK ? Promise.resolve({ data: { success: true, accessToken: "mock-token" } }) : client.post("/auth/login", data);

export const uploadMedia = (formData) =>
  USE_MOCK
    ? mockUploadMedia(formData)
    : client.post("/media/upload", formData, { headers: { "Content-Type": "multipart/form-data" } });

export const checkStatus = (jobId) =>
  USE_MOCK ? mockCheckStatus(jobId) : client.get(`/media/status/${jobId}`);

export const getResult = (jobId) =>
  USE_MOCK ? mockGetResult(jobId) : client.get(`/media/result/${jobId}`);
