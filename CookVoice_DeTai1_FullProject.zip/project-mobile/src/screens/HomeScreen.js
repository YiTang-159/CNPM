import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#FFFDF9" }}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.badge}>🍜  Dành cho nhà sáng tạo nội dung ẩm thực</Text>
        <Text style={styles.title}>Đưa công thức nấu ăn của bạn ra thế giới</Text>
        <Text style={styles.desc}>
          Quay hoặc chọn video nấu ăn, chọn ngôn ngữ nguồn/đích — CookVoice tự
          động dịch và tạo giọng thuyết minh mới cho công thức của bạn.
        </Text>
        <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate("Upload")}>
          <Text style={styles.btnText}>Bắt đầu dịch video</Text>
        </TouchableOpacity>

        <View style={styles.featureCard}>
          <Text style={styles.featureIcon}>🎙️</Text>
          <Text style={styles.featureTitle}>Thuyết minh tự động</Text>
          <Text style={styles.featureDesc}>Tạo giọng đọc mới cho công thức, không chỉ dịch phụ đề.</Text>
        </View>
        <View style={styles.featureCard}>
          <Text style={styles.featureIcon}>🌍</Text>
          <Text style={styles.featureTitle}>Đa ngôn ngữ</Text>
          <Text style={styles.featureDesc}>Hỗ trợ Việt, Anh, Nhật, Hàn, Pháp và nhiều ngôn ngữ khác.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: "center" },
  badge: { backgroundColor: "#FBF1E7", color: "#B84E1F", fontWeight: "600", fontSize: 13, padding: 8, borderRadius: 999, marginBottom: 16 },
  title: { fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 12, color: "#33261F" },
  desc: { fontSize: 15, color: "#7A6A5D", textAlign: "center", marginBottom: 24, lineHeight: 22 },
  btn: { backgroundColor: "#D9622B", paddingVertical: 14, paddingHorizontal: 28, borderRadius: 12, marginBottom: 24 },
  btnText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  featureCard: { backgroundColor: "#FBF1E7", borderRadius: 12, padding: 16, width: "100%", marginBottom: 12 },
  featureIcon: { fontSize: 22, marginBottom: 6 },
  featureTitle: { fontWeight: "700", fontSize: 15, marginBottom: 4, color: "#33261F" },
  featureDesc: { fontSize: 13, color: "#7A6A5D" },
});
