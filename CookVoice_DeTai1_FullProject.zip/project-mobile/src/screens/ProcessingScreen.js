import { useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";
import ProgressBar from "../components/ProgressBar";
import { useUploadStatus } from "../hooks/useUploadStatus";

const STAGE_LABEL = {
  pending: "Đang chờ xử lý...",
  extracting: "Đang tách audio...",
  translating: "Đang dịch công thức...",
  dubbing: "Đang tạo giọng thuyết minh...",
};

export default function ProcessingScreen({ route, navigation }) {
  const { jobId } = route.params;
  const { status, percent, error } = useUploadStatus(jobId);

  useEffect(() => {
    if (status === "done") navigation.replace("Result", { jobId });
  }, [status]);

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.error}>Xử lý thất bại: {error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.stage}>🍳 {STAGE_LABEL[status] || "Đang xử lý..."}</Text>
      <ProgressBar percent={percent} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center", backgroundColor: "#FFFDF9" },
  stage: { fontSize: 16, marginBottom: 16, textAlign: "center", color: "#33261F" },
  error: { color: "#D33333", fontSize: 16, textAlign: "center" },
});
